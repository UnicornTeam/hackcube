TODO: Replace logging with print
DONE: Standardized all response format
DONE: Check if shell exist before execute it.
DONE: Change response parser in Front-End
TODO: Use class to Standardized all response format
TODO: Remove create_thumbnail.Remove gen_file_name.
TODO: Add document, include receive and return parameter
DONE: Add get update_firmware_log api, after finish, return 304
DONE: Add HD_INFO api
TODO: Add more TESTING ENV configuration and more test code
TODO: Add ID to each fetched item.
DONE: [WIFI Page] STA => Client list
DONE: RF Page RF Item

TODO: In server: STA_List (not associated)  => None
TODO: Pagination 居中
TODO: WIFI下拉闪烁 替换table组件
