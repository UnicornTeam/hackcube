#!/bin/bash
set -e
set -x
dir=`pwd`
rm /root/serial_file/test -f
cp $dir/test   /root/serial_file/

rm /root/web    -r
cp $dir/web  /root/ -r

rm /var/www/html/*  -r

cp /root/web/dist/* /var/www/html/ -r


